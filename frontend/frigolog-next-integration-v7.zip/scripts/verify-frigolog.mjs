import { readFileSync, existsSync, statSync } from 'node:fs';
import { join } from 'node:path';
const root=process.cwd();
const base='frontend/src/app/templates/frigolog';
const required=['page.tsx','FrigologTemplate.tsx','FrigologUI.tsx','frigolog.css'];
for(const file of required){const path=join(root,base,file);if(!existsSync(path))throw Error(`Missing ${path}`)}
const tsx=readFileSync(join(root,base,'FrigologTemplate.tsx'),'utf8');
for(const name of ['cold-storage.jpg','team.jpg','fleet.jpg']){const asset=join(root,'frontend/public/lovable/frigolog',name);if(!existsSync(asset))throw Error(`Missing asset ${asset}`);if(statSync(asset).size<10000)throw Error(`Suspiciously small image ${name}`);if(!tsx.includes(name))throw Error(`Missing image reference ${name}`)}
for(const id of ['inicio','servicos','sobre','operacao','contato'])if(!tsx.includes(`id="${id}"`))throw Error(`Missing section ${id}`);
const ui=readFileSync(join(root,base,'FrigologUI.tsx'),'utf8');
const css=readFileSync(join(root,base,'frigolog.css'),'utf8');
const page=readFileSync(join(root,base,'page.tsx'),'utf8');
for(const token of ['aria-modal="true"','Escape','Tab','previous?.focus()'])if(!ui.includes(token))throw Error(`Dialog accessibility check failed: ${token}`);
for(const token of ['.frigolog-template','--color-primary','prefers-reduced-motion','.hero-image'])if(!css.includes(token))throw Error(`Scoped stylesheet check failed: ${token}`);
if(!page.includes('FrigologTemplate')||!page.includes('./frigolog.css'))throw Error('Preview route wiring invalid');
console.log('FRIGOLOG static smoke checks: PASS');
