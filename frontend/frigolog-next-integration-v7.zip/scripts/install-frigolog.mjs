#!/usr/bin/env node
/** Install the original Frigolog integration into an existing PageNova checkout. */
import { existsSync, readFileSync, mkdirSync, copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
const target=resolve(process.argv[2] || '.');
const source=resolve(import.meta.dirname,'..');
const branch='feature/lovable-fidelity-crm-generator';
function git(...args){return execFileSync('git',args,{cwd:target,encoding:'utf8'}).trim()}
if(!existsSync(join(target,'.git')))throw Error('Destination must be a Git checkout');
if(git('branch','--show-current')!==branch)throw Error(`Refusing to modify branch other than ${branch}`);
if(git('status','--porcelain'))throw Error('Working tree must be clean before installation');
if(!existsSync(join(target,'frontend/package.json')))throw Error('PageNova frontend/package.json not found');
const files=['frontend/src/app/templates/frigolog/page.tsx','frontend/src/app/templates/frigolog/FrigologTemplate.tsx','frontend/src/app/templates/frigolog/FrigologUI.tsx','frontend/src/app/templates/frigolog/frigolog.css','frontend/public/lovable/frigolog/team.jpg','frontend/public/lovable/frigolog/cold-storage.jpg','frontend/public/lovable/frigolog/fleet.jpg','scripts/verify-frigolog.mjs'];
for(const f of files)if(!existsSync(join(source,f)))throw Error(`Package missing ${f}`);
for(const f of files)if(existsSync(join(target,f)))throw Error(`Refusing to overwrite existing ${f}`);
const created=[];
try {
 for(const f of files){const to=join(target,f);mkdirSync(dirname(to),{recursive:true});copyFileSync(join(source,f),to);created.push(to)}
 execFileSync('node',['scripts/verify-frigolog.mjs'],{cwd:target,stdio:'inherit'});
 console.log('Files installed. Run: npm --prefix frontend run build');
 console.log('No commit or push performed. Inspect changes before committing.');
} catch(e){for(const f of created)rmSync(f,{force:true});throw e}
