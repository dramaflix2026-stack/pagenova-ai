import FrigologTemplate from "./FrigologTemplate";
import "./frigolog.css";
export default function Page(){return <FrigologTemplate />;}
