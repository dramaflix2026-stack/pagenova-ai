"use client";
import React, { useEffect, useRef } from "react";
type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "ghost" | "link" | "outline" | "secondary"; size?: "icon"; asChild?: boolean };
export function Button({ variant, size, asChild, className = "", children, ...rest }: ButtonProps) {
  const classes = `frigolog-button ${variant ? `frigolog-button--${variant}` : ""} ${size === "icon" ? "frigolog-button--icon" : ""} ${className}`;
  if (asChild && React.isValidElement(children)) return React.cloneElement(children as React.ReactElement<{className?:string}>, { className: `${classes} ${(children.props as {className?:string}).className ?? ""}` });
  return <button type="button" {...rest} className={classes}>{children}</button>;
}
const DialogContext = React.createContext<() => void>(() => {});
export function Dialog({open,onOpenChange,children}:{open:boolean;onOpenChange:(v:boolean)=>void;children:React.ReactNode}) {
  const panelRef = useRef<HTMLDivElement>(null);
  useEffect(()=>{if(!open)return;const previous=document.activeElement as HTMLElement | null; const oldOverflow=document.body.style.overflow;document.body.style.overflow="hidden"; panelRef.current?.focus();return()=>{document.body.style.overflow=oldOverflow;previous?.focus()}},[open]);
  useEffect(()=>{if(!open)return;const fn=(e:KeyboardEvent)=>{if(e.key==="Escape"){onOpenChange(false);return;}if(e.key==="Tab"){const focusable=Array.from(panelRef.current?.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')??[]);if(!focusable.length){e.preventDefault();return;}const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}};document.addEventListener("keydown",fn);return()=>document.removeEventListener("keydown",fn)},[open,onOpenChange]);
  if(!open)return null;
  return <DialogContext.Provider value={()=>onOpenChange(false)}><div className="frigolog-dialog-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onOpenChange(false)}}><div role="dialog" aria-modal="true" aria-label="Informações Frigolog" tabIndex={-1} ref={panelRef} className="frigolog-dialog-panel">{children}</div></div></DialogContext.Provider>;
}
export function DialogContent({children,className=""}:{children:React.ReactNode;className?:string}) {const close=React.useContext(DialogContext);return <div className={className}><button type="button" className="frigolog-dialog-close" onClick={close} aria-label="Fechar">×</button>{children}</div>}
export function DialogHeader({children}:{children:React.ReactNode}){return <div>{children}</div>}
export function DialogTitle({children,className=""}:{children:React.ReactNode;className?:string}){return <h2 className={className}>{children}</h2>}
export function DialogDescription({children,className=""}:{children:React.ReactNode;className?:string}){return <p className={className}>{children}</p>}
