"use client";
import { useState } from "react";
import { Truck, Snowflake, Route as RouteIcon, Radar, ShieldCheck, Menu, X, ArrowUpRight, ArrowRight, Check, MessageCircle, Thermometer } from "lucide-react";
import { Button, Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./FrigologUI";
const coldStorage = "/lovable/frigolog/cold-storage.jpg";
const fleet = "/lovable/frigolog/fleet.jpg";
const team = "/lovable/frigolog/team.jpg";

const services = [
  { icon: Truck, name: "Transporte refrigerado", text: "Congelados e refrigerados viajando com a temperatura certa.", detail: "Frota própria com baús e carretas refrigerados, mantendo cargas entre −18 °C e +4 °C do carregamento à entrega. Registro de temperatura contínuo durante todo o trajeto, com protocolos próprios para carnes in natura, congeladas e derivados." },
  { icon: Snowflake, name: "Armazenagem frigorífica", text: "Câmaras frias em SP, prontas para o seu estoque.", detail: "Câmaras frias para congelados (até −18 °C) e refrigerados (0 °C a +4 °C), com paletização organizada, controle de lote e validade, inventário em tempo real e área para cross docking de cargas de passagem." },
  { icon: RouteIcon, name: "Distribuição em SP", text: "Capital, ABC, interior e litoral — com janela agendada.", detail: "Coleta e entrega programadas para distribuidoras, atacadistas, food service e varejo. Roteirização por janela horária combinada, entregas em docas frigorificadas e comunicação proativa em cada etapa da rota." },
  { icon: Radar, name: "Rastreabilidade e compliance", text: "Cada viagem com histórico completo de temperatura.", detail: "Telemetria embarcada e sensores nas câmaras geram relatórios de temperatura por viagem e por paleta. Documentação alinhada às exigências sanitárias, pronta para auditorias dos seus clientes e órgãos de controle." },
];
const stats = [
  { value: "24/7", label: "Monitoramento de temperatura" },
  { value: "−18 °C a +4 °C", label: "Faixa controlada em toda a operação" },
  { value: "Frota própria", label: "Baús e carretas refrigerados" },
  { value: "SP inteira", label: "Capital, ABC, interior e litoral" },
];
const links = [{ label: "Início", href: "#inicio" }, { label: "O que fazemos", href: "#servicos" }, { label: "Quem somos", href: "#sobre" }, { label: "Frota e cobertura", href: "#operacao" }, { label: "Contato", href: "#contato" }];

function Brand() {
  return <a href="#inicio" aria-label="Frigolog — início" className="flex min-w-0 items-center gap-2.5 text-primary"><svg className="h-10 w-10 shrink-0" viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M24 6v36M8.5 15l31 18M39.5 15l-31 18" /><path d="M24 12.5l-4-4M24 12.5l4-4M24 35.5l-4 4M24 35.5l4 4M13.5 17.5l-5.5-1M13.5 17.5l-1 5.5M34.5 30.5l5.5 1M34.5 30.5l1-5.5M34.5 17.5l5.5-1M34.5 17.5l1 5.5M13.5 30.5l-5.5 1M13.5 30.5l-1-5.5" /></svg><span className="min-w-0"><span className="brand-name block">Frigolog</span><span className="brand-sub block">logística frigorífica · são paulo</span></span></a>;
}

export default function FrigologTemplate() {
  const [menu, setMenu] = useState(false);
  const [quote, setQuote] = useState(false);
  const [service, setService] = useState<number | null>(null);
  const selectedService = service === null ? null : services[service];
  return <div className="frigolog-template">
    <header className="site-header sticky top-0 z-30 border-b border-border bg-background">
      <div className="site-container grid h-full grid-cols-[minmax(0,1fr)_auto] items-center gap-5 md:flex md:justify-between">
        <Brand />
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Menu principal">{links.map((link, i) => <a key={link.href} href={link.href} className={`text-[13px] transition-colors hover:text-primary ${i === 0 ? 'font-semibold text-primary' : 'text-muted-foreground'}`}>{link.label}</a>)}</nav>
        <Button className="hidden h-11 px-5 text-xs md:inline-flex" onClick={() => setQuote(true)}>Solicitar cotação <ArrowUpRight /></Button>
        <Button variant="ghost" size="icon" className="shrink-0 md:hidden" aria-label={menu ? "Fechar menu" : "Abrir menu"} onClick={() => setMenu(!menu)}>{menu ? <X /> : <Menu />}</Button>
      </div>
      {menu && <nav aria-label="Menu móvel" className="absolute w-full border-b border-border bg-background p-5 shadow-sm">{links.map(link => <a key={link.href} href={link.href} onClick={() => setMenu(false)} className="block py-3 text-sm">{link.label}</a>)}<Button onClick={() => { setMenu(false); setQuote(true); }}>Solicitar cotação <ArrowUpRight /></Button></nav>}
    </header>
    <main>
      <section id="inicio" className="hero">
        <img className="hero-image" src={coldStorage} alt="Câmara fria de armazenagem de carnes com paletes, caixas e empilhadeira em operação" width={1536} height={1024} fetchPriority="high" />
        <div className="site-container hero-content fade-in">
          <p className="eyebrow mb-6 flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> Cadeia do frio sem interrupção</p>
          <h1>A temperatura certa,<br />do seu frigorífico<br /><span className="text-primary">até o destino.</span></h1>
          <p className="mt-6 max-w-[420px] text-[15px] leading-7 text-muted-foreground">Transporte refrigerado, armazenagem em câmaras frias e distribuição em toda a São Paulo — com a temperatura monitorada em cada quilômetro.</p>
          <Button className="mt-7 h-12 gap-6 px-6 text-[13px]" onClick={() => setQuote(true)}>Solicitar cotação <ArrowUpRight /></Button>
          <div className="mt-8 flex items-center gap-2.5 text-xs text-muted-foreground"><ShieldCheck className="h-4 w-4 text-primary" /><span>Frota própria e registros de temperatura para auditoria.</span></div>
        </div>
      </section>
      <section className="border-b border-border bg-secondary/50 py-7" aria-label="Números da operação">
        <div className="site-container grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{stats.map(item => <div key={item.value} className="flex items-center gap-4 lg:justify-center"><Thermometer className="h-6 w-6 shrink-0 text-primary" strokeWidth={1.4} /><div className="min-w-0"><p className="text-[15px] font-bold leading-tight">{item.value}</p><p className="mt-1 text-xs text-muted-foreground">{item.label}</p></div></div>)}</div>
      </section>
      <section id="servicos" className="py-20">
        <div className="site-container">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-5 sm:flex sm:justify-between"><div className="min-w-0"><p className="eyebrow mb-3">O que fazemos</p><h2 className="section-heading">Da doca fria do frigorífico<br />à doca do seu cliente.</h2></div><span className="hidden max-w-[280px] text-[13px] leading-6 text-muted-foreground md:block">Soluções completas de logística frigorífica para frigoríficos, distribuidoras e indústria de carnes.</span></div>
          <div className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{services.map((item, i) => <article key={item.name} className="service-card flex min-h-[250px] flex-col rounded-lg border border-border bg-card p-6"><span className="service-icon"><item.icon className="h-6 w-6" strokeWidth={1.4} /></span><h3 className="mt-5 text-[16px] font-semibold">{item.name}</h3><p className="mt-3 text-[13px] leading-6 text-muted-foreground">{item.text}</p><Button variant="link" className="mt-auto justify-start gap-2 px-0 pt-5 text-xs" onClick={() => setService(i)}>Saiba mais <ArrowUpRight /></Button></article>)}</div>
        </div>
      </section>
      <section id="sobre" className="bg-muted py-20">
        <div className="site-container grid items-center gap-12 md:grid-cols-2 md:gap-20">
          <img className="about-image w-full" src={team} alt="Equipe de logística conferindo caixas de carne em câmara fria" width={1024} height={1024} loading="lazy" />
          <div><p className="eyebrow mb-4">Quem somos</p><h2 className="section-heading">Operação de frio<br />não é tarefa para amador.</h2><p className="mt-6 text-sm leading-7 text-muted-foreground">A Frigolog nasceu em São Paulo para resolver o gargalo mais crítico da indústria de carnes: manter a cadeia do frio intacta entre a saída do frigorífico e a chegada ao cliente. Trabalhamos com processos documentados, equipe treinada para câmara fria e equipamentos dimensionados para cargas pesadas.</p><p className="mt-4 text-sm leading-7 text-muted-foreground">Não terceirizamos o elo mais sensível da sua operação. Quem cuida da sua carga somos nós — com registro de tudo.</p><div className="mt-7 space-y-3">{['Frota própria, sem terceirização da cadeia do frio', 'Registros de temperatura prontos para auditoria', 'Equipe treinada para carga e descarga em câmara'].map(text => <p className="flex items-center gap-3 text-[13px]" key={text}><Check className="h-4 w-4 text-primary" />{text}</p>)}</div><Button variant="outline" className="mt-8 h-11 gap-7" asChild><a href="#operacao">Conheça a operação <ArrowRight /></a></Button></div>
        </div>
      </section>
      <section id="operacao" className="py-20"><div className="site-container"><div className="mb-9 text-center"><p className="eyebrow mb-3">Frota e cobertura</p><h2 className="section-heading">Onde sua carga precisa chegar,<br />nós vamos — com frio.</h2><p className="mx-auto mt-4 max-w-lg text-sm leading-7 text-muted-foreground">Operação baseada na Grande São Paulo, com atendimento à capital, ABC, interior e litoral. Frota dimensionada de baús refrigerados a carretas frigoríficas, conforme o volume e a distância da sua operação.</p></div><img src={fleet} alt="Frota de caminhões refrigerados em docas de um centro de distribuição ao anoitecer" width={1536} height={1024} loading="lazy" className="aspect-[2/1] w-full rounded-md object-cover md:aspect-[2.6/1]" /></div></section>
      <section id="contato" className="bg-primary py-16 text-primary-foreground"><div className="site-container grid gap-8 md:grid-cols-[minmax(0,1fr)_auto] md:items-center"><div className="min-w-0"><p className="mb-4 text-[10px] font-semibold uppercase tracking-[2px] text-primary-foreground/70">Vamos operar juntos?</p><h2 className="section-heading">Sua carga não pode esperar<br />fora da temperatura.</h2><p className="mt-4 text-sm text-primary-foreground/75">Conte para a gente o volume, a faixa de temperatura e os destinos. Retorna em breve com uma proposta.</p></div><Button variant="secondary" className="h-12 gap-5 justify-self-start px-6" onClick={() => setQuote(true)}><MessageCircle /> Solicitar cotação <ArrowUpRight /></Button></div></section>
    </main>
    <footer className="py-9"><div className="site-container grid gap-7 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center"><Brand /><p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Frigolog — Logística frigorífica. Todos os direitos reservados.</p></div></footer>
    <Dialog open={quote} onOpenChange={setQuote}><DialogContent className="sm:max-w-md"><DialogHeader><DialogTitle className="text-xl">Solicitar cotação</DialogTitle><DialogDescription className="pt-3 leading-6">O contato comercial estará disponível assim que os dados da Frigolog forem cadastrados. Em breve, você poderá enviar volume, faixa de temperatura e destinos para receber uma proposta.</DialogDescription></DialogHeader><Button className="mt-3" onClick={() => setQuote(false)}>Entendido</Button></DialogContent></Dialog>
    <Dialog open={selectedService !== null} onOpenChange={open => { if (!open) setService(null); }}><DialogContent className="sm:max-w-md"><DialogHeader><DialogTitle className="text-xl">{selectedService?.name}</DialogTitle><DialogDescription className="pt-3 leading-7">{selectedService?.detail}</DialogDescription></DialogHeader><Button className="mt-4" onClick={() => { setService(null); setQuote(true); }}>Solicitar cotação <ArrowUpRight /></Button></DialogContent></Dialog>
  </div>;
}
