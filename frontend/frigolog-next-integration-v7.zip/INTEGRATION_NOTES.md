# FRIGOLOG V7 — PageNova integration

Install only on `feature/lovable-fidelity-crm-generator` using `node scripts/install-frigolog.mjs /path/to/pagenova-ai` from this extracted package. Installer refuses a dirty tree or existing target files.

## Verification

1. Run `node scripts/verify-frigolog.mjs` in the repository.
2. Run `npm --prefix frontend run build` (requires PageNova dependencies and environment).
3. Test `/templates/frigolog` at desktop/mobile widths and check images, dialogs, navigation and typography.
4. Commit only after successful build; deploy to preview, not production.

## Important

This is a standalone visual template, not integrated with the PageNova editor, site persistence, publication or AI generation. The original source images are preserved. V7 scopes semantic Tailwind color classes to Frigolog so the host brand palette does not override the design. No build or deployment is claimed.
